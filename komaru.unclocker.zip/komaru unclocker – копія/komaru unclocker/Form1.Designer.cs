﻿namespace komaru_unclocker
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.boostPC = new System.Windows.Forms.Button();
            this.openTools = new System.Windows.Forms.Button();
            this.lockPC = new System.Windows.Forms.Button();
            this.restartPC = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // boostPC
            // 
            this.boostPC.Location = new System.Drawing.Point(259, 308);
            this.boostPC.Name = "boostPC";
            this.boostPC.Size = new System.Drawing.Size(200, 40);
            this.boostPC.TabIndex = 0;
            this.boostPC.Text = "Очистити ПК";
            this.boostPC.Click += new System.EventHandler(this.boostPC_Click);
            // 
            // openTools
            // 
            this.openTools.Location = new System.Drawing.Point(514, 203);
            this.openTools.Name = "openTools";
            this.openTools.Size = new System.Drawing.Size(200, 52);
            this.openTools.TabIndex = 1;
            this.openTools.Text = "Диспетчер та Реєстр";
            this.openTools.Click += new System.EventHandler(this.openTools_Click);
            // 
            // lockPC
            // 
            this.lockPC.Location = new System.Drawing.Point(514, 288);
            this.lockPC.Name = "lockPC";
            this.lockPC.Size = new System.Drawing.Size(200, 60);
            this.lockPC.TabIndex = 2;
            this.lockPC.Text = "Заблокувати (Win+L)";
            this.lockPC.Click += new System.EventHandler(this.lockPC_Click);
            // 
            // restartPC
            // 
            this.restartPC.Location = new System.Drawing.Point(514, 131);
            this.restartPC.Name = "restartPC";
            this.restartPC.Size = new System.Drawing.Size(200, 52);
            this.restartPC.TabIndex = 3;
            this.restartPC.Text = "Перезавантаження";
            this.restartPC.Click += new System.EventHandler(this.restartPC_Click);
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.textBox1.Location = new System.Drawing.Point(287, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(172, 22);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "KOMARU UNCLOCKER";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(714, 360);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.boostPC);
            this.Controls.Add(this.openTools);
            this.Controls.Add(this.lockPC);
            this.Controls.Add(this.restartPC);
            this.Name = "Form1";
            this.Text = "Komaru Unclocker";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button boostPC;
        private System.Windows.Forms.Button openTools;
        private System.Windows.Forms.Button lockPC;
        private System.Windows.Forms.Button restartPC;
        private System.Windows.Forms.TextBox textBox1;
    }
}