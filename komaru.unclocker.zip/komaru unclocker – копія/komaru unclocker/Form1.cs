﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace komaru_unclocker
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern bool LockWorkStation();

        public Form1()
        {
            InitializeComponent();
        }

        // Кнопка 1: Очищення
        private void boostPC_Click(object sender, EventArgs e)
        {
            string[] processesToClose = { "opera", "utorrent" };
            foreach (string procName in processesToClose)
            {
                Process[] processes = Process.GetProcessesByName(procName);
                foreach (Process p in processes)
                {
                    try { p.Kill(); } catch { }
                }
            }
            ClearDirectory(Path.GetTempPath());
            if (Directory.Exists(@"C:\Windows\Prefetch")) ClearDirectory(@"C:\Windows\Prefetch");

            MessageBox.Show("ПК очищено! 🚀");
        }

        // Кнопка 2: Інструменти
        private void openTools_Click(object sender, EventArgs e)
        {
            try { Process.Start("taskmgr.exe"); } catch { }
            try { Process.Start("regedit.exe"); } catch { }
        }

        // Кнопка 3: Блокування (Win + L)
        private void lockPC_Click(object sender, EventArgs e)
        {
            LockWorkStation();
        }

        // Кнопка 4: Перезавантаження
        private void restartPC_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Перезавантажити ПК?", "Увага", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) Process.Start("shutdown", "/r /t 0");
        }

        private void ClearDirectory(string path)
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(path);
                foreach (FileInfo file in di.GetFiles()) try { file.Delete(); } catch { }
                foreach (DirectoryInfo dir in di.GetDirectories()) try { dir.Delete(true); } catch { }
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}